// Makefile appends preprocessor flags instead now
#ifndef RADIANT_ABOUTMSG
#error no RADIANT_ABOUTMSG defined
#endif
