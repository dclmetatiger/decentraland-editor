// Makefile appends preprocessor flags instead now
#ifndef RADIANT_VERSION
#error no RADIANT_VERSION defined
#endif
#ifndef RADIANT_MAJOR_VERSION
#error no RADIANT_MAJOR_VERSION defined
#endif
#ifndef RADIANT_MINOR_VERSION
#error no RADIANT_MINOR_VERSION defined
#endif
