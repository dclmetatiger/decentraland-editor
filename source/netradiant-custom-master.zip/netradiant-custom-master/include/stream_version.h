// version defines for q3map stream
#define Q3MAP_STREAM_VERSION "1"
