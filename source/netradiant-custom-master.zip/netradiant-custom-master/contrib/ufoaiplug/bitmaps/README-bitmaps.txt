ufoaiplug bitmaps are in setup/data/tools/plugins/bitmaps 
