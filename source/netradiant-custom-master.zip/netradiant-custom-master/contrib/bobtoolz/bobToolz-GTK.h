
#pragma once

extern QWidget *g_pRadiantWnd;
