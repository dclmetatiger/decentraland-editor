BobToolz GTK: v1100
[=================]

Date:
[===]
16.05.01

The multipurpose Quake3 Mappers Tool
[==================================]

Author: 	djbob
Other work: 	q3terra, ctftoolz, EECA mod

eMail:		gbiggans@uglab.eee.strath.ac.uk (NO SPAM thank u very much :P)

www:		www.planetquake.com/toolz
		www.planetquake.com/eeca

IRC:		#freepq irc.fdf.net
		#qeradiant irc.telefragged.com

Files Contained In This Package:
[==============================]

Readme.txt		--- This file.
Changelog.txt		--- Version information.
bobToolz.dll		--- The plugin itself.
bt/*.txt		--- A few text files required by the plugin.


What's a boy to do?
[=================]

Put The plugin in your GTKRadiant plugins folder:
e.g. mine: c:\gamez\quake3\GTKRadiant\plugins

Run Radiant, and select the toolz from the dropdown plugin menu.

Help is available in the form of a manual on my site.



For the new q3map bug highlighting feature, run autocaulk-build mini prt, then run autocaulk.
identify an area which has been caulked incorrectly, then reopen the map, select the q3map bug highlight option, and wait.
once the selected brushes appear, u have 2 choices, 

a) press i and remove all the original brushes, or 
b) keep going with both sets (slower, but more useful)

navigate to the problem region, you should find that the set of inverse brushes that has been built is missing a brush
at the problem area, i suppose the next problem is finding out why :]

this function is mainly provided for other coders to show the problem, and is probably of little use to anyone else,
but u never know.


Coming Soon:
[==========]
Region area saving. perhaps, if i get the time to finish it.


Testing, Feedback & Ideas:
[========================]

	Akuma, Casey, Cartman2K, maverik, rayden, nephilim_goth and god knows who else.
	Thx to you all.

Thanx:
[====]

	ttimo, da man :]
	spog, for his often baffling advice.... and questions....
	Thx to rr2do2, for his linux conversion, and removing the "evil" (his words :]) MFC code.
	Thx to RKone, for improving my q3w sig.
	Azr for giving me ops in #qeradiant, k3wl :]
	Everyone at the Quake3World Forums, I think of you all as my little worshippers :P
	id Software, of course.