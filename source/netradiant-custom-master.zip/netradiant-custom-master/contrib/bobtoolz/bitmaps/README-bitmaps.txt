bobtoolz bitmaps are in setup/data/tools/plugins/bitmaps 
