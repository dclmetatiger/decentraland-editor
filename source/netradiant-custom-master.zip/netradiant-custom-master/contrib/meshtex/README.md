MeshTex is a plugin for GtkRadiant 1.5.  More interesting user documentation at [neogeographica.com](http://neogeographica.com/).

Doxygen-generated code documentation is in the docs/html folder; viewable online at [rawgithub.com](https://rawgithub.com/neogeographica/MeshTex/master/docs/html/index.html).

Build instructions are in the COMPILING file.

MeshTex is licensed under the GNU GPL v2.  The LICENSE file contains a copy of the GPL.
